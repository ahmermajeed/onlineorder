<?php

namespace App\Data\Models;

use Illuminate\Database\Eloquent\Model;

class DeliveryChargesDetails extends Model
{
    protected $table = 'delivery_charges_details';
}

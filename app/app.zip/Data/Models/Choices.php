<?php

namespace App\Data\Models;

use Illuminate\Database\Eloquent\Model;

class Choices extends Model
{
    protected $table = 'choices';


}
